package com.facebook.base;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Date;
import java.util.NoSuchElementException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.io.FileHandler;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;

public class Base {
	public static WebDriver driver = null;
	public static String browserName=null;
	public static Properties config;
	public static FileInputStream fis;
	public static String testURL;
	public static String browser;
	public ExtentTest extTest;
	
	public Base(ExtentTest extTest){
		config = new Properties();
		
		if(driver==null){
			try {
				fis = new FileInputStream(System.getProperty("user.dir")
						+ "\\resources\\config\\Config.properties");
			} catch (FileNotFoundException e) {
			}
			try {
				config.load(fis);
				
			} catch (IOException e) {
				e.printStackTrace();
			}
			testURL = config.getProperty("url");
			browser = config.getProperty("browser");
			
			if(browser.equals("chrome")){
				System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"\\resources\\driverexes\\chromedriver.exe");
				ChromeOptions options = new ChromeOptions();
				options.addArguments("--disable-notifications");
				driver = new ChromeDriver(options);					
			}else if(browser.equals("firefox")){
				System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir")+"\\resources\\driverexes\\geckodriver.exe");
				driver = new FirefoxDriver();
			}
			
		}
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get(testURL);
		this.extTest = extTest;
		
	}
	
	
	
	public void quilDriver() {
		driver.quit();
	}
	
	public void clickAction(WebElement ele, String msg) {
		try {
			ele.click();
			extTest.log(Status.PASS, msg);
		} catch (NoSuchElementException e) {
			extTest.log(Status.FAIL, e.getMessage());
		}
	}
	
	public void enterText(WebElement ele, String str, String msg) {
		try {
			
			ele.sendKeys(str);
			extTest.log(Status.PASS,msg ,MediaEntityBuilder.createScreenCaptureFromPath(captureScreenshot()).build());
		} catch (Exception e) {
			
				extTest.log(Status.FAIL,msg);
				try {
					extTest.log(Status.FAIL,msg ,MediaEntityBuilder.createScreenCaptureFromPath(captureScreenshot()).build());
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			
		}
	}
	
		
		public static String captureScreenshot() {

			File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

			Date d = new Date();
			String screenshotName = d.toString().replace(":", "_").replace(" ", "_") + ".jpg";

			try {
				
				FileHandler.copy(scrFile, new File(System.getProperty("user.dir") + "\\Reports\\" + screenshotName));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return screenshotName;

		
		}
	
	
	
	
	
}
