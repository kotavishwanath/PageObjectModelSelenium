package com.favebook.tests;

import java.lang.reflect.Method;
import java.util.Hashtable;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.facebook.pages.FBHomePage;
import com.facebook.pages.FBLoginPage;
import com.facebook.utils.ExtentManager;
import com.facebook.utils.Utils;

public class FBLogInOutTest /*extends FBLoginPage*/{
	
	FBLoginPage lo;
	FBHomePage fbHome;
	public ExtentReports extent;
	public ExtentTest test;
	
	
	
	@BeforeClass
	public void beforClass(){
		
		extent = ExtentManager.createInstance("E:\\Sharath\\PageObjectModelSelenium-master\\Reports\\extends1.html");
	}

	@BeforeMethod
	public void beforMet(Method m){
		test = extent.createTest(m.getName());
	}
	
	@AfterClass
	public void ac() {
		ExtentManager.saveReport(extent);
	}
	
	@Test(dataProviderClass=Utils.class,dataProvider="dp")
	public void loginVerification(Hashtable<String,String> data) throws InterruptedException {		
		lo = new FBLoginPage(test);
		lo.enterEmail(data.get("username"));
		lo.enterPassword(data.get("password"));
		lo.clickOnLoginButton();
		fbHome = new FBHomePage(test); 
		Thread.sleep(4000);
		fbHome.clickSettingsButton();
		Thread.sleep(4000);
		fbHome.clickOnLogoutButton();
//		lo.quilDriver();

	}
	
	
//	@Test
	public void loutVerification() throws InterruptedException {	
//		test.log(Status.INFO, "Loging test started");
//		fbHome =new FBHomePage(test); 
//		Thread.sleep(4000);
//		fbHome.clickSettingsButton();
//		Thread.sleep(4000);
//		fbHome.clickOnLogoutButton();
//		lo.quilDriver();
	}
}
