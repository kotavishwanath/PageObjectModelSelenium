package com.favebook.tests;

import java.lang.reflect.Method;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.facebook.pages.FBHomePage;
import com.facebook.pages.FBLoginPage;
import com.facebook.utils.ExtentManager;

public class FBLogInOutTest /*extends FBLoginPage*/{
	
	FBLoginPage lo;
	FBHomePage fbHome;
	ExtentManager em= new ExtentManager() ;
	public ExtentReports extent;
	public ExtentTest test;
	
	
	
	@BeforeClass
	public void beforClass(){
		
		extent = em.createInstance("E:\\Sharath\\PageObjectModelSelenium-master\\Reports\\extends1.html");
	}

	@BeforeMethod
	public void beforMet(Method m){
		test = extent.createTest(m.getName());
	}
	
	@AfterClass
	public void ac() {
		em.saveReport(extent);
	}
	
	@Test
	public void loginVerification() throws InterruptedException {		
		lo = new FBLoginPage(test);		 
		lo.enterEmail("dagahtest123@gmail.com");
		lo.enterPassword("Test@1234");
		lo.clickOnLoginButton();
		fbHome =new FBHomePage(test); 
		Thread.sleep(4000);
		fbHome.clickSettingsButton();
		Thread.sleep(4000);
		fbHome.clickOnLogoutButton();

	}
	
	
	@Test
	public void loutVerification() throws InterruptedException {	
		test.log(Status.INFO, "Loging test started");
		fbHome =new FBHomePage(test); 
		Thread.sleep(4000);
		fbHome.clickSettingsButton();
		Thread.sleep(4000);
		fbHome.clickOnLogoutButton();
		lo.quilDriver();
	}
}
