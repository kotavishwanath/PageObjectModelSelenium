package com.facebook.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.facebook.base.Base;

public class FBHomePage extends Base {
	
	public FBHomePage(ExtentTest test){
		super(test);
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(how=How.XPATH, using="//div[text()='Account Settings']") WebElement settingButton;
	@FindBy(how=How.LINK_TEXT, using="Log Out") WebElement logoutButton;
	
	public void clickSettingsButton() {
//		settingButton.click();
		
		clickAction(settingButton,"settingButton");
	}
	
	public void clickOnLogoutButton() {
//		logoutButton.click();
		clickAction(logoutButton,"logoutButton");
	}
}
